package com.cg.banking.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

@Controller
public class BankController {

	@Autowired
	BankingServices serviceBank;

	HttpSession session;

	// ShowingLoginPage
	@RequestMapping(value = "showLogin")
	public ModelAndView showLoginPage() {
		return new ModelAndView("login", "customer", new Customer());
	}

	// LoginAttempt
	@RequestMapping(value = "login", method = RequestMethod.POST)
	public String loginCustomer(@ModelAttribute("customer") Customer cust,	Model model, HttpServletRequest req) {
		String result = "index";
		String message = null;
		try {
			if (serviceBank.authenticateCustomer(cust)) {
				session = req.getSession();
				Customer customer = serviceBank.getCustomerDetails(cust.getCustomerId());
				session.setAttribute("customer", customer);
				getAllAccounts(customer,session);
				result = "home";
			} else {
				message = "Username Or password Incorrect";
				result = "index";
			}
		} catch (CustomerNotFoundException e) {
			e.printStackTrace();
			message = e.getMessage();
			result = "index";
		} catch (BankingServicesDownException e) {
			e.printStackTrace();
			message = "Something went wrong!! Please try again."+ e.getMessage();
			result = "index";
		} catch (SQLException e) {
			message = "Something went wrong!! Please try again."+ e.getMessage();
			e.printStackTrace();
			result = "index";
		} catch (Exception e) {
			message = "Something went wrong!! Please try again." + e.toString();
			e.printStackTrace();
			result = "index";
		} finally {
			model.addAttribute("message", message);
			return result;
		}
	}

	// Show SignUp Page
	@RequestMapping(value = "showSignupPage")
	public ModelAndView showSignupPage() {
		return new ModelAndView("signup", "customer", new Customer());
	}

	// Adding Customer in DB
	@RequestMapping(value = "addCustomer")
	public String addCustomer(@ModelAttribute("customer") Customer cust,Model model) {
		String message = null;
		try {
			int custId = serviceBank.acceptCustomerDetails(cust);
			if (custId != 0) {
				message = "Congratulations! You are successfully registered. Your Customer Id is"
						+ custId;
			}
		} catch (BankingServicesDownException e) {
			e.printStackTrace();
			message = "Something went wrong!! Please try again.";
		} catch (SQLException e) {
			message = "Something went wrong!! Please try again.";
		}
		model.addAttribute("message", message);
		return "index";
	}

	// show Update Page
	@RequestMapping(value = "showUpdatePage")
	public String showUpdatePage(@RequestParam(value = "id") int id, Model model) {
		// Customer customer = (Customer) session.getAttribute("customer");
		Customer cust;
		try {
			cust = serviceBank.getCustomerDetails(id);
			model.addAttribute("customer", cust);
		} catch (CustomerNotFoundException e) {
			e.printStackTrace();
		} catch (BankingServicesDownException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "detail";
	}

	// Show OpenAccount Page
	@RequestMapping(value = "openAccountPage")
	public ModelAndView openAccountPage(@RequestParam(value = "id") int id,
			HttpSession session) {
		session.setAttribute("customerId", id);
		return new ModelAndView("openAccountPage", "account", new Account());
	}

	@RequestMapping(value = "openAccount")
	public ModelAndView openAccount(@ModelAttribute("account") Account account,
			Model model, HttpSession session) {
		try {
			int accountNo = serviceBank.openAccount((int) session.getAttribute("customerId"), account);
			getAllAccounts(serviceBank.getCustomerDetails((int) session.getAttribute("customerId")),session);
			model.addAttribute("message","New account added successfully. Your account number is "+ accountNo+". Your Pin is "+account.getPinNumber());
		} catch (InvalidAmountException e) {
			e.printStackTrace();
		} catch (CustomerNotFoundException e) {
			e.printStackTrace();
		} catch (InvalidAccountTypeException e) {
			e.printStackTrace();
		} catch (BankingServicesDownException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (AccountNotFoundException e) {
			e.printStackTrace();
		}
		return new ModelAndView("home");
	}

	// Show transaction
	@RequestMapping(value = "performTransaction")
	public ModelAndView openTransactionPage(@RequestParam(value = "id") int id,
			HttpSession session) {
		session.setAttribute("customerId", id);
		return new ModelAndView("openTransactionPage", "trans",
				new Transaction());
	}

	// Delete customer
	@RequestMapping(value = "deleteCustomer")
	public ModelAndView deleteCustomer(@RequestParam(value = "id") int id) {
		String message = null;
		try {
			if (serviceBank.deleteCustomer(id))
				message = "Customer removed Successfully.";
		} catch (BankingServicesDownException | SQLException| CustomerNotFoundException e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		return new ModelAndView("index", "message", message);
	}
	
	//Delete Account
	@RequestMapping(value = "deleteAccount")
	public ModelAndView deleteAccount(@RequestParam(value="accountNo") int accountNo,HttpSession session) {
		String message = null;
		try {
			Customer cust = (Customer) session.getAttribute("customer");
			if (serviceBank.deleteAccount(cust.getCustomerId(), accountNo)){
				getAllAccounts(cust,session);
				message = "account removed Successfully.";				
			}
		} catch (BankingServicesDownException | SQLException| CustomerNotFoundException e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		return new ModelAndView("home", "message", message);
	}
	
	//Change pin
	@RequestMapping(value = "showChangePin")
	public ModelAndView showChangePin(@RequestParam(value="accountNo") int accountNo,HttpSession session) {
		session.setAttribute("accountNo", accountNo);
		return new ModelAndView("changePin");
	}
	
	@RequestMapping(value = "changePin")
	public ModelAndView changePin(@RequestParam(value="oldPin") int oldPin,@RequestParam(value="newPin")int newpin,HttpSession session) {
		String message = null;
		try {
			Customer cust = (Customer) session.getAttribute("customer");
			if (serviceBank.changeAccountPin(cust.getCustomerId(), (int)session.getAttribute("accountNo"),oldPin, newpin)){
				getAllAccounts(cust,session);
				message = "Pin updated Successfully.";				
			}
		} catch (BankingServicesDownException | SQLException| CustomerNotFoundException | AccountNotFoundException | InvalidPinNumberException e) {
			e.printStackTrace();
			message = e.getMessage();
		}
		return new ModelAndView("home", "message", message);
	}
	
	//all accounts
	public void getAllAccounts(Customer customer,HttpSession session){
		List<Account> allAccounts= null;
		try {
			allAccounts = serviceBank.getcustomerAllAccountDetails(customer.getCustomerId());
			session.setAttribute("allAccounts", allAccounts);
		} catch (BankingServicesDownException | CustomerNotFoundException| SQLException e) {
			e.printStackTrace();
		}
	}
	//Deposit
	@RequestMapping(value = "deposit")
	public ModelAndView depositAmount(@RequestParam("accountNo")int accountNo,@RequestParam("amount")int amount) {
		try {
			float balance = serviceBank.depositAmount((int) session.getAttribute("customerId"), amount, accountNo);
			getAllAccounts((Customer) session.getAttribute("customer"), session);
		} catch (CustomerNotFoundException e) {
			e.printStackTrace();
			return new ModelAndView("home");
		} catch (SQLException e) {
			e.printStackTrace();
			return new ModelAndView("home");
		} catch (AccountNotFoundException e) {
			e.printStackTrace();
		} catch (BankingServicesDownException e){
			e.printStackTrace();
		}
		return new ModelAndView("home");
	}
}
