package com.cg.banking.aspects;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.exceptions.CustomerNotFoundException;

@ControllerAdvice(basePackages="com.cg.banking.controller.BankController")
public class BankingExceptionHandlerAdvice {
	
	@ExceptionHandler(CustomerNotFoundException.class)
	public ModelAndView handleCustomerNotFoundException(){
		ModelAndView mv = new ModelAndView();
		mv.addObject("customer");
		/*mv.addModel("exception",e.message());
		mv.addView("login");*/
		return null;
		
	}
}
