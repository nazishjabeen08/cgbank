package com.cg.banking.services;

import java.sql.SQLException;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

@Service("service")
@Transactional
public class BankingServicesImpl implements BankingServices {

	@Autowired
	BankingDAOServices daoBank;

	@Override
	public int openAccount(int customerId, Account account) throws InvalidAmountException,
			CustomerNotFoundException, InvalidAccountTypeException,
			BankingServicesDownException, SQLException, AccountNotFoundException {
		account.setStatus("OPEN");
		account.setPinNumber(generateNewPin());
		return daoBank.insertAccount(customerId, account);
	}

	@Override
	public float depositAmount(int customerId, int amount,int accountNo) throws CustomerNotFoundException, AccountNotFoundException,
			BankingServicesDownException, SQLException {
		Account acct = daoBank.getAccount(customerId, accountNo) ;
		System.out.println("Balance "+(acct.getAccountBalance()+amount));
		acct.setAccountBalance(acct.getAccountBalance()+amount);
		Transaction trans = new Transaction();
		trans.setAmount(amount);
		trans.setTransactionType("Deposit");
		return daoBank.insertTransaction(customerId,acct, trans);
	
	}

	@Override
	public float withdrawAmount(int customerId, int accountNo, float amount,
			int pinNumber) throws InsufficientAmountException,
			CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException, SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean fundTransfer(int customerIdTo, int accountNoTo,
			int customerIdFrom, int accountNoFrom, float transferAmount,
			int pinNumber) throws InsufficientAmountException,
			CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException, SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer getCustomerDetails(int customerId)
			throws CustomerNotFoundException, BankingServicesDownException, SQLException {
		return daoBank.getCustomer(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, int accountNo)
			throws CustomerNotFoundException, AccountNotFoundException,
			BankingServicesDownException, SQLException {
		return daoBank.getAccount(customerId, accountNo);
	}

	@Override
	public int generateNewPin()throws CustomerNotFoundException, AccountNotFoundException,
			BankingServicesDownException, SQLException {
		return daoBank.generatePin();
	}

	@Override
	public boolean changeAccountPin(int customerId, int accountNo,int oldPinNumber, int newPinNumber)
			throws CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException, SQLException {
		Account acct = daoBank.getAccount(customerId, accountNo);
		if(acct != null){
			if(oldPinNumber == acct.getPinNumber()){
				acct.setPinNumber(newPinNumber);
				if(daoBank.updateAccount(customerId, acct))
					return true;
			}
			else throw new InvalidPinNumberException("Old pin is incorrect!! Try Again");
		}
		else 
			throw new AccountNotFoundException("Account not found!!");
		return false;
	}

	@Override
	public List<Customer> getAllCustomerDetails()
			throws BankingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> getcustomerAllAccountDetails(int customerId)
			throws BankingServicesDownException, CustomerNotFoundException, SQLException {
		return daoBank.getAccounts(customerId);
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int customerId,
			int accountNo) throws BankingServicesDownException,
			CustomerNotFoundException, AccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String accountStatus(int customerId, int accountNo)
			throws BankingServicesDownException, CustomerNotFoundException,
			AccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void close() throws BankingServicesDownException {
		daoBank.close1();
	}

	@Override
	public int acceptCustomerDetails(Customer customer)
			throws BankingServicesDownException, SQLException {
		return daoBank.insertCustomer(customer);
	}

	@Override
	public boolean deleteCustomer(int customerId) throws BankingServicesDownException, SQLException, CustomerNotFoundException {
		Customer cust = daoBank.getCustomer(customerId);
		if(cust != null)
			return daoBank.deleteCustomer(customerId);
		else  
			throw new CustomerNotFoundException("Customer not found!! Try Again");
	}
	
	@Override
	public boolean deleteAccount(int customerId,int accountNo) throws BankingServicesDownException, SQLException, CustomerNotFoundException {
		Customer cust = daoBank.getCustomer(customerId);
		if(cust != null)
			return daoBank.deleteAccount(customerId, accountNo);
		else  
			throw new CustomerNotFoundException("Customer not found!! Try Again");
	}

	@Override
	public boolean authenticateCustomer(Customer customer)throws BankingServicesDownException,
			SQLException, CustomerNotFoundException {
		Customer cust = daoBank.getCustomer(customer.getCustomerId());
		if (cust != null ){
			if (customer.getPassword().equals(cust.getPassword()))
				return true;
			else	return false;
		}
		else
			throw new CustomerNotFoundException("Customer not found!! Try Again");
	}

	public BankingDAOServices getDaoBank() {
		return daoBank;
	}

	public void setDaoBank(BankingDAOServices daoBank) {
		this.daoBank = daoBank;
	}

}
