package com.cg.banking.services;

import java.sql.SQLException;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public interface BankingServices {

	int openAccount(int customerId, Account account)
			throws InvalidAmountException, CustomerNotFoundException,
			InvalidAccountTypeException, BankingServicesDownException,
			SQLException, AccountNotFoundException;

	float depositAmount(int customerId, int amount, int accountNo)
			throws CustomerNotFoundException, AccountNotFoundException,
			BankingServicesDownException, SQLException;

	float withdrawAmount(int customerId, int accountNo, float amount,
			int pinNumber) throws InsufficientAmountException,
			CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException, SQLException;

	boolean fundTransfer(int customerIdTo, int accountNoTo, int customerIdFrom,
			int accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, CustomerNotFoundException,
			AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException, SQLException;

	Customer getCustomerDetails(int customerId)
			throws CustomerNotFoundException, BankingServicesDownException, SQLException;

	Account getAccountDetails(int customerId, int accountNo)
			throws CustomerNotFoundException, AccountNotFoundException,
			BankingServicesDownException, SQLException;

	public int generateNewPin()throws CustomerNotFoundException, AccountNotFoundException,
			BankingServicesDownException, SQLException;

	public boolean changeAccountPin(int customerId, int accountNo,
			int oldPinNumber, int newPinNumber)

	throws CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException, SQLException;

	List<Customer> getAllCustomerDetails() throws BankingServicesDownException;

	List<Account> getcustomerAllAccountDetails(int customerId)
			throws BankingServicesDownException, CustomerNotFoundException, SQLException;

	List<Transaction> getAccountAllTransaction(int customerId, int accountNo)
			throws BankingServicesDownException, CustomerNotFoundException,
			AccountNotFoundException;

	public String accountStatus(int customerId, int accountNo)
			throws BankingServicesDownException, CustomerNotFoundException,
			AccountNotFoundException;

	void close() throws BankingServicesDownException;

	int acceptCustomerDetails(Customer customer)
			throws BankingServicesDownException, SQLException;

	boolean deleteCustomer(int customerID) throws BankingServicesDownException, SQLException, CustomerNotFoundException;

	public boolean deleteAccount(int customerId,int accountNo) throws BankingServicesDownException, SQLException, CustomerNotFoundException;
	public boolean authenticateCustomer(Customer customer)
			throws CustomerNotFoundException, BankingServicesDownException, SQLException;

}
