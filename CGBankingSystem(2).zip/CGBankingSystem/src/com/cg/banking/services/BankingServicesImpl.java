package com.cg.banking.services;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
@Service
@Transactional
public class BankingServicesImpl implements BankingServices {
	@Autowired
	BankingDAOServices bDao;
	@Override
	public long openAccount(int customerId, String accountType,
			float initBalance) throws InvalidAmountException,
			CustomerNotFoundException, InvalidAccountTypeException,
			BankingServicesDownException {
		
		return 0;
	}

	@Override
	public float depositAmount(int customerId, int accountNo, float amount)
			throws CustomerNotFoundException, AccountNotFoundException,
			BankingServicesDownException {
		try {
			Account acc=bDao.getAccount(customerId, accountNo);
			acc.setAccountBalance(acc.getAccountBalance()+amount);
			bDao.updateAccount(customerId, acc);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return amount;
	}

	@Override
	public float withdrawAmount(int customerId, int accountNo, float amount,
			int pinNumber) throws InsufficientAmountException,
			CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException, SQLException {
		try {
			Account acc=bDao.getAccount(customerId, accountNo);
			acc.setAccountBalance(acc.getAccountBalance()-amount);
			bDao.updateAccount(customerId, acc);
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return amount;
	}

	@Override
	public float fundTransfer(int customerIdTo, int accountNoTo,
			int customerIdFrom, int accountNoFrom, float transferAmount,
			int pinNumber) throws InsufficientAmountException,
			CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException, SQLException {
		Account aDebit=bDao.getAccount(customerIdFrom, accountNoFrom);
		Account acCredit=bDao.getAccount(customerIdTo, accountNoTo);
		aDebit.setAccountBalance(aDebit.getAccountBalance()-transferAmount);
		bDao.updateAccount(customerIdFrom, aDebit);
		acCredit.setAccountBalance(acCredit.getAccountBalance()+transferAmount);
		bDao.updateAccount(customerIdTo, acCredit);
		return transferAmount;
	}

	@Override
	public Customer getCustomerDetails(int customerId)
			throws CustomerNotFoundException, BankingServicesDownException {
		Customer customer = null;
		try {
			 customer= bDao.getCustomer(customerId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customer;
	}

	@Override
	public Account getAccountDetails(int customerId, int accountNo)
			throws CustomerNotFoundException, AccountNotFoundException,
			BankingServicesDownException {
			
		Account account=null;
		try {
			account = bDao.getAccount(customerId, accountNo);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return account;
	}

	@Override
	public int generateNewPin(int customerId, Account account)
			throws CustomerNotFoundException, AccountNotFoundException,
			BankingServicesDownException {
		int pin=0;
		try {
			 pin= bDao.generatePin(customerId, account);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pin;
	}

	@Override
	public boolean changeAccountPin(int customerId, int accountNo,
			int oldPinNumber, int newPinNumber)
			throws CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException {
		Account acc=null;
		try {
			acc=bDao.getAccount(customerId, accountNo);
			int old=acc.getPinNumber();
			if(old==oldPinNumber){
				acc.setPinNumber(newPinNumber);
				bDao.updateAccount(customerId, acc);
			}else{
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return true;
	}

	@Override
	public List<Customer> getAllCustomerDetails()
			throws BankingServicesDownException {
		List list =new ArrayList();
		try {
				 list=bDao.getCustomers();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return list;
	
	}

	@Override
	public List<Account> getcustomerAllAccountDetails(int customerId)
			throws BankingServicesDownException, CustomerNotFoundException {
		List list=new ArrayList();
		try {
			list= bDao.getAccounts(customerId);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
		
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int customerId,
			int accountNo) throws BankingServicesDownException,
			CustomerNotFoundException, AccountNotFoundException {
				return null;
	}

	@Override
	public String accountStatus(int customerId, int accountNo)
			throws BankingServicesDownException, CustomerNotFoundException,
			AccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void close() throws BankingServicesDownException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Customer acceptCustomerDetails(Customer customer)
			throws BankingServicesDownException {
		try {
			customer= bDao.insertCustomer(customer);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customer;
	}

	@Override
	public boolean deleteCustomer(int customerId)
			throws BankingServicesDownException, ClassNotFoundException {
		try {
			bDao.deleteCustomer(customerId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}

	@Override
	public boolean authenticateCustomer(Customer customer)
			throws CustomerNotFoundException, BankingServicesDownException, SQLException {
	Customer cust=null;
		try {
			cust = bDao.getCustomer(customer.getCustomerId());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	if(cust==null){
		return false;
	}else
		return true;
	}

	@Override
	public Account insertAccount(int customerId, Account account)
			throws InvalidAmountException, CustomerNotFoundException,
			InvalidAccountTypeException, BankingServicesDownException {
		
		try {
			account= bDao.insertAccount(customerId, account);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return account;
	}

	@Override
	public boolean deleteAccount(int customerId, int accountNo)
			throws SQLException {
		bDao.deleteAccount(customerId, accountNo);
		return true;
	}

	@Override
	public Transaction insertTransaction(int customerId, int accountNo,
			Transaction transaction) throws SQLException {

		return bDao.insertTransaction(customerId, accountNo, transaction);
	}
	
}
