package com.cg.banking.daoservices;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

@Repository
public class BankingDAOServicesImpl implements BankingDAOServices {
	@PersistenceContext
	private EntityManager em;
	@Override
	public Customer insertCustomer(Customer customer) throws SQLException {
		em.persist(customer);
		em.flush();
		return customer;
	}

	@Override
	public Account insertAccount(int customerId, Account account)
			throws SQLException {
	Customer customer = em.find(Customer.class, customerId);
	account.setCustomer(customer);
	em.persist(account);
		em.flush();
		return account;
	}

	@Override
	public Account updateAccount(int customerId, Account account)
			throws SQLException {
		em.merge(account);
		em.flush();
		return account;
	}

	@Override
	public int generatePin(int customerId, Account account) throws SQLException {
		
		double pin=Math.random()*10000;
	
		return  (int) pin;
	}

	@Override
	public Transaction insertTransaction(int customerId, int accountNo,
			Transaction transaction) throws SQLException {
		Account account = em.find(Account.class, accountNo);
		transaction.setAccount(account);
		em.persist(transaction);
		em.flush();
		return transaction;
	}

	@Override
	public boolean deleteCustomer(int customerId) throws SQLException {
		Query qry = em.createQuery("Delete from Customer e where e.customerId=:customerId");
		qry.setParameter("customerId",customerId).executeUpdate();
		return true;
	}

	@Override
	public boolean deleteAccount(int customerId, int accountNo)
			throws SQLException {
		 em.remove(accountNo);
		return true;
	}

	@Override
	public Customer getCustomer(int customerId) throws SQLException {
			return em.find(Customer.class, customerId);
	}

	@Override
	public Account getAccount(int customerId, int accountNo)
			throws SQLException {

		return em.find( Account.class,accountNo);
	}

	@Override
	public List<Customer> getCustomers() throws SQLException {
		TypedQuery<Customer> query = em.createQuery("select c from Customer c",Customer.class);
		
		return query.getResultList();
	}

	@Override
	public List<Account> getAccounts(int customerId) throws SQLException {
		TypedQuery<Account>query=em.createQuery("select a from Account a where a.customer.customerId=:customerId",Account.class);
		query.setParameter("customerId",customerId);
		return query.getResultList();
	}

	@Override
	public List<Transaction> getTransaction(int accountNo) throws SQLException {
		TypedQuery<Transaction> query = em.createQuery("select e from Employee e",Transaction.class);
		
		return query.getResultList();
	}

	@Override
	public void close1() {
			
	}

	}