package com.cg.banking.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

@Controller
public class FrontController {
	@Autowired
	BankingServices service;
	HttpSession session;

	@RequestMapping("authenticate")
	public String authenticate(@RequestParam("username")int id ,@RequestParam("password")String password,HttpServletRequest request) throws CustomerNotFoundException, BankingServicesDownException, SQLException{
		Customer customer=new Customer(id,password);
		boolean cust=service.authenticateCustomer(customer);
		if(cust==true){
			Customer customer1=service.getCustomerDetails(id);
			String pass=customer1.getPassword();
			if(password.equals(pass)){
			session=request.getSession(true);
			session.setAttribute("customer", customer);
			return "CustomerHome";}else
				return "Error";
		}else if((id==101)&&password.equals("admin")){
			return"Home";
			
		}else
				return"Error";
		
	
	}
	
	@ModelAttribute("cust")
	public Customer getCustomer(){
		
		return new Customer();
	}
	
	@RequestMapping("showForm")
	public String showForm(){
		
		return "InsertCustomer";
		
	}
	
	@RequestMapping("insertData")
	public String insertData(@ModelAttribute("cust")Customer customer,Model model){
		try {
			
			customer=service.acceptCustomerDetails(customer);
			session.setAttribute("cust", customer);
			model.addAttribute("msg","Customer with id"+ customer.getCustomerId());
		
		} catch (BankingServicesDownException e) {
			e.printStackTrace();
		}		
		return "SuccessInsert";	
	}
	@ModelAttribute("account")
	public Account getAccount(){
		return new Account();
	}
	@RequestMapping("showAccForm")
	public String showAccForm(){
		
		return "InsertAccount";
	
	}
	@RequestMapping("insertAccData")
	public String insertAccData(@ModelAttribute("account")Account acc,@RequestParam("customerId")int customerId,Model model){
		try {
			int pin=service.generateNewPin(customerId, acc);
			acc.setPinNumber(pin);
			service.insertAccount(customerId, acc);
			model.addAttribute("msg","account no is "+acc.getAccountNo());
		} catch (InvalidAmountException | CustomerNotFoundException
				| InvalidAccountTypeException | BankingServicesDownException | AccountNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "SuccessInsert";
	
	}
	@RequestMapping("deleteAcc")
	public String deleteAccForm(){
		
		return "EnterIdDel";
	
	}
	@RequestMapping("delete")
	public String delete(@RequestParam("customerId")int customerId,@RequestParam("accountNo")int accountNo,Model model){
		try {
			service.deleteAccount(customerId, accountNo);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "SuccessDel";
	
	}
	@RequestMapping("deleteCust")
	public String deleteCustForm(){
		
		return "EnterCustIdDel";
	
	}
	@RequestMapping("deleteCustomer")
	public String deleteCust(@RequestParam("customerId")int customerId,Model model){
		System.out.println("before try");
		try {
		
			service.deleteCustomer(customerId);
			
		} catch (ClassNotFoundException | BankingServicesDownException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "SuccessCustDel";
	}
	@RequestMapping("searchCust")
	public String searchCust(){
		
		return "EnterIdSearch";
	
	}
	@RequestMapping("toSearch")
	public String showCust(@RequestParam("customerId")int customerId,Model model){
		try {
			Customer customer=service.getCustomerDetails(customerId);
			model.addAttribute("customer",customer);
		} catch (CustomerNotFoundException | BankingServicesDownException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "ShowCustomer";
		
	}
	@RequestMapping("generate")
	public String generate(){
		
		return "GeneratePin";
	
	}
	
	@RequestMapping("showPin")
	public String generate(@RequestParam("customerId")int customerId,@RequestParam("accountNo")int accountNo,Account account,Model model){
		
			try {
				int pin=service.generateNewPin(customerId, account);
				System.out.println("pin is"+pin);
				model.addAttribute("msg","pin is"+pin);
			} catch (CustomerNotFoundException | AccountNotFoundException
					| BankingServicesDownException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		return "showPin";
		}
	@RequestMapping("showListCust")
	public String showCustList(Model model){
		try {
			model.addAttribute("custList",service.getAllCustomerDetails());
		} catch (BankingServicesDownException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "ListOfCust";
	
	}
	@RequestMapping("showCustAcc")
	public String showCustAcc(){
		
		return "EnterCustAcc";
	
	}
	@RequestMapping("showAccList")
	public String showCustAccount(@RequestParam("customerId")int customerId,Model model){
		try {
			model.addAttribute("custAccList",service.getcustomerAllAccountDetails(customerId));
		} catch (BankingServicesDownException | CustomerNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "ListOfCustAcc";
	
	}
	@RequestMapping("changePin")
	public String changePin(){
		
		return "ChangePin";
	
	}
	@RequestMapping("updatePin")
	public String updatePin(@RequestParam("customerId")int customerId,@RequestParam("accountNo")int accountNo,@RequestParam("oldPin")int oldPin,@RequestParam("newPin")int newPin,Model model){
		try {
			model.addAttribute("pinNumber",service.changeAccountPin(customerId, accountNo, oldPin, newPin));
			//model.addAttribute("newPin", newPin);
		} catch (CustomerNotFoundException | AccountNotFoundException
				| InvalidPinNumberException | BankingServicesDownException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "PinChanged";
	
	}
	@RequestMapping("withDrawl")
	public String withDrawlMoney(){
		
		return "ShowToWithDrawl";
	
	}
	@RequestMapping("withDrawlComplete")
	public String withDrawlComplete(@RequestParam("customerId")int customerId,@RequestParam("accountNo")int accountNo,@RequestParam("amount")float amount,@RequestParam("pinNumber")int pinNumber,Model model){
		try {
			Transaction trans=new Transaction(amount,"Debited");
			model.addAttribute("amount","Amount Debited is -"+service.withdrawAmount(customerId, accountNo, amount, pinNumber));
			service.insertTransaction(customerId, accountNo, trans);
		} catch (InsufficientAmountException | CustomerNotFoundException
				| AccountNotFoundException | InvalidPinNumberException
				| BankingServicesDownException | AccountBlockedException
				| SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "WithDrawlSuccess";
	
	}
	@RequestMapping("deposit")
	public String depositMoney(){
		
		return "ShowToDeposit";
	
	}
	@RequestMapping("depositComplete")
	public String depositComplete(@RequestParam("customerId")int customerId,@RequestParam("accountNo")int accountNo,@RequestParam("amount")float amount,@RequestParam("pinNumber")int pinNumber,Model model){
		try {
			Transaction trans=new Transaction(amount,"Credited");
			model.addAttribute("amount", "Amount Credited is-"+service.depositAmount(customerId, accountNo, amount));
			service.insertTransaction(customerId, accountNo, trans);
		} catch (CustomerNotFoundException | AccountNotFoundException
				| BankingServicesDownException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "WithDrawlSuccess";
	
	}
	@RequestMapping("fundTransfer")
	public String fundTransfer(){
		
		return "ShowToTransfer";
	
	}
	@RequestMapping("transferComplete")
	public String transferComplete(@RequestParam("customerIdFrom")int customerId1,@RequestParam("accountNoFrom")int accountNo1,@RequestParam("customerIdTo")int customerId2,@RequestParam("accountNoTo")int accountNo2,@RequestParam("amountTransfer")float amount,@RequestParam("pinNumber")int pinNumber,Model model){
		Transaction trans1=new Transaction(amount,"Credited");
		Transaction trans2=new Transaction(amount,"Debited");
		try {
		model.addAttribute("amount","Amount transfer is -"+	service.fundTransfer(customerId1, accountNo1, customerId2, accountNo2, amount, pinNumber));
			service.insertTransaction(customerId1, accountNo1, trans1);
			service.insertTransaction(customerId2, accountNo2, trans2);
		} catch (InsufficientAmountException | CustomerNotFoundException
				| AccountNotFoundException | InvalidPinNumberException
				| BankingServicesDownException | AccountBlockedException
				| SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "SuccessTransfer";
	
	}
}
