package com.cg.banking.beans;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import javax.persistence.Table;
@Entity
@Table(name="Cust123")
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int customerId;
	private String firstName,lastName,emailId,panCard,password;
	@OneToMany(mappedBy="customer" ,cascade=CascadeType.ALL)

	private Map<Integer,Account> accounts=new HashMap<Integer, Account>();

	@Embedded
	@OrderColumn
	private	Addres address;


	public int getCustomerId() {
		return customerId;
	}


	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	public String getPanCard() {
		return panCard;
	}


	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	

	public Map<Integer, Account> getAccounts() {
		return accounts;
	}


	public void setAccounts( Account accounts) {
		if(this.accounts != null)
			this.accounts.put(this.accounts.size()+1,accounts);
		else
			System.out.println("null data");
	}


	public Addres getAddress() {
		return address;
	}


	public void setAddress(Addres address) {
		this.address = address;
	}


	public Customer(int customerId, String firstName, String lastName,
			String emailId, String panCard, String password,
			Map<Integer, Account> accounts, Addres address) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.panCard = panCard;
		this.password = password;
		this.accounts = accounts;
		this.address = address;
	}


	public Customer() {
		super();
	}


	public Customer(int customerId, String password) {
		super();
		this.customerId = customerId;
		this.password = password;
	}


	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", firstName="
				+ firstName + ", lastName=" + lastName + ", emailId=" + emailId
				+ ", panCard=" + panCard + ", password=" + password
				+ ", accounts=" + accounts + ", address=" + address + "]";
	}

	public void addAccount(Account account) {
		account.setCustomer(this);			//this will avoid nested cascade
		this.getAccounts().put(1,account);
	}
}
