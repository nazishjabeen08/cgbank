package com.cg.banking.beans;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.ManyToAny;
@Entity

public class Account implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	//@SequenceGenerator(name="seq1",sequenceName="acc_Id")
	@GeneratedValue(strategy=GenerationType.TABLE)
	private int accountNo;
	private String accountType;
	private float accountBalance;
	private int pinNumber;
	private String status;
	private int pinCounter;
	
	@ManyToOne
	@JoinColumn(name="customerId")
	private Customer customer;
	
	@OneToMany(mappedBy="account",cascade=CascadeType.ALL)
	private Map<Integer,Transaction>transactions=new HashMap<>();

	
	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public float getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}

	public int getPinNumber() {
		return pinNumber;
	}

	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getPinCounter() {
		return pinCounter;
	}

	public void setPinCounter(int pinCounter) {
		this.pinCounter = pinCounter;
	}

	public Map<Integer, Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(Transaction transactions) {
		if(this.transactions!= null)
			this.transactions.put(this.transactions.size()+1,transactions);
		else
			System.out.println("null data");
	}

	public Account(int accountNo, String accountType, float accountBalance,
			int pinNumber, String status, int pinCounter, Customer customer,
			Map<Integer, Transaction> transactions) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.accountBalance = accountBalance;
		this.pinNumber = pinNumber;
		this.status = status;
		this.pinCounter = pinCounter;
		this.customer = customer;
		this.transactions = transactions;
	}

	public Account( String accountType, float accountBalance,
			int pinNumber, String status, int pinCounter) {
		super();
		
		this.accountType = accountType;
		this.accountBalance = accountBalance;
		this.pinNumber = pinNumber;
		this.status = status;
		this.pinCounter = pinCounter;
	}

	public Account() {
		super();
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountType="
				+ accountType + ", accountBalance=" + accountBalance
				+ ", pinNumber=" + pinNumber + ", status=" + status
				+ ", pinCounter=" + pinCounter + ", customer=" + customer
				+ ", transactions=" + transactions + "]";
	}

	
	
}
